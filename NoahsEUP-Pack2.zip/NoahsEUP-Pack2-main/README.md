> # NoahsEUP-Pack2
> A FiveM EUP set, this includes a hoodie, a hat, and a tshirt! All made by Noah.
> 
> 
> 
> 
> **Clothing List:**
> - Kappa Black Hoodie (2 Varients)
> - Brixton Hoodie
> - Addidas Hoodie (3 Varients)
> - Diamond Hoodie
> - PIT Viper Hoodie
> - Bang Hoodie (2 Varients)
> - Louis vuitton Hoodie
> 
> (11 TOTAL HOODIES)
> 
> > **Credits:** Noah Brahim
> 
> **DISCORD:** discord.gg/9GCKTKK3Wc
> 
> 
> 
> > **Pictures:**
> 
> ![](https://cdn.discordapp.com/attachments/801599642638352416/802336003456761876/unknown.png)
> ![](https://cdn.discordapp.com/attachments/801599642638352416/802335069976395806/unknown.png)
> > 
